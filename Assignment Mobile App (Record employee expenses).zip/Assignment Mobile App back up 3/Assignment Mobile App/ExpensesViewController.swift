//
//  ViewController.swift
//  Assignment Mobile App
//
//  Created by Kim Lee on 28/03/2022.
//

import UIKit

class ExpensesViewController: UIViewController, UIImagePickerControllerDelegate & UINavigationControllerDelegate {
    
    var expenses:ExpensesEntry?

    
    @IBOutlet weak var receiptPhoto: UIImageView!
    @IBOutlet weak var dateTextField: UITextField!
    @IBOutlet weak var saveButton: UIBarButtonItem!
    @IBOutlet weak var employeeNameTextField: UITextField!
    @IBOutlet weak var totalExpenseTextField: UITextField!
    @IBOutlet weak var dateReceiptTextField: UITextField!
    @IBOutlet weak var paidDateTextField: UITextField!
    @IBOutlet weak var expenseSumarryTextField: UITextField!
    @IBAction func paidButton(_ sender: UIButton) {
    }
    //add date and time button to textfield
    @IBAction func TodayDateButton(_ sender: UIButton) {
        let currentDate = Date()
        
        let format = DateFormatter()
        format.timeStyle = .medium
        format.dateStyle = .medium
        
        let dateTime = format.string(from: currentDate)
        
        dateTextField.text = dateTime
        
    }
    
    @IBAction func addReceiptFromLibrary(_ sender: UITapGestureRecognizer) {
        //hides keyboard
        employeeNameTextField.resignFirstResponder()
        
        //use UI ImagePicker Controller allows to select a photo from library
        let imagePickerController = UIImagePickerController()
        
        //only allow photos from library
        imagePickerController.sourceType = .photoLibrary
        
        imagePickerController.delegate = self
        present(imagePickerController, animated: true, completion: nil)
    }
    @IBAction func cancelExpenses(_ sender: UIBarButtonItem) {
        let isPresentinginAddExpenseMode = presentingViewController is UINavigationController
        if isPresentinginAddExpenseMode{
            dismiss(animated: true, completion: nil)
        }
        
        else{
            //cancel back to the table view
            if let owningNavigationController = navigationController{
                owningNavigationController.popViewController(animated: true)
            }
        }
    
    }
    
    
    //VAT button func
    @IBAction func VAT_Button(_ sender: UIButton) {
        if sender.isSelected{
            sender.isSelected = false
        }
        else{
            sender.isSelected = true
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //Do any additoonal setup after loading the view.
        if let expenses = expenses {
            employeeNameTextField.text = expenses.name
            receiptPhoto.image = expenses.photo
            dateTextField.text = expenses.date
            paidDateTextField.text = expenses.datePaid
            expenseSumarryTextField.text = expenses.summary
            totalExpenseTextField.text = expenses.price
            dateReceiptTextField.text = expenses.dateReceipt
            
        dateTextField.isEnabled = false
        }
    }

    override func prepare(for segue:UIStoryboardSegue, sender: Any?){
        guard let button = sender as?
            UIBarButtonItem, button === saveButton
        else{
            return;
        }
        //code above runs when save button is clicked.
    
        let name = employeeNameTextField.text ?? ""
        let date = dateTextField.text ?? ""
        let photo = receiptPhoto.image
        let datePaid = paidDateTextField.text ?? ""
        let summary = expenseSumarryTextField.text ?? ""
        let price = totalExpenseTextField.text ?? ""
        let dateReceipt = dateReceiptTextField.text ?? ""
        
        expenses = ExpensesEntry(name: name, date: date, photo: photo, datePaid: datePaid, summary: summary, price: price, dateReceipt: dateReceipt);
        
        
        
        
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        guard let selectedImage = info[UIImagePickerController.InfoKey.originalImage] as? UIImage
        else{
            print("error loading selected image, dismissing image picker. ")
            dismiss(animated: true, completion: nil)
            return;
        }
        //shows selected image
        receiptPhoto.image = selectedImage
        dismiss(animated: true, completion: nil)
    }
    
    
}

