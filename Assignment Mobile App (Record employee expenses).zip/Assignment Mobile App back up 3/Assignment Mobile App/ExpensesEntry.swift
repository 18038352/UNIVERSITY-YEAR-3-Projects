//
//  ExpensesEntry.swift
//  Assignment Mobile App
//
//  Created by Kim Lee on 28/03/2022.
//

import UIKit

class ExpensesEntry:NSObject, NSCoding{

    func encode(with coder: NSCoder) {
        coder.encode(name, forKey: PropertyKey.name)
        coder.encode(date, forKey: PropertyKey.date)
        coder.encode(photo, forKey: PropertyKey.photo)
        coder.encode(datePaid, forKey: PropertyKey.datePaid)
        coder.encode(summary, forKey: PropertyKey.summary)
        coder.encode(price, forKey: PropertyKey.price)
        coder.encode(dateReceipt, forKey: PropertyKey.dateReceipt)
    }
    required convenience init?(coder: NSCoder) {
        guard let name = coder.decodeObject(forKey: PropertyKey.name)as? String else {
            print("Unable to decode the receipt entry")
            return nil;
        }
        
       
        guard let date = coder.decodeObject(forKey: PropertyKey.date)as? String else {
            print("Unable to decode the receipt entry")
            return nil;
            }
        
        guard let datePaid = coder.decodeObject(forKey: PropertyKey.datePaid)as? String else {
            print("Unable to decode the receipt entry")
            return nil;
        }
        
        guard let summary = coder.decodeObject(forKey: PropertyKey.summary)as? String else {
            print("Unable to decode the receipt entry")
            return nil;
        }
        
        guard let price = coder.decodeObject(forKey: PropertyKey.price)as? String else {
            print("Unable to decode the receipt entry")
            return nil;
        }
        
        guard let dateReceipt = coder.decodeObject(forKey: PropertyKey.dateReceipt)as? String else {
            print("Unable to decode the receipt entry")
            return nil;
        }
        
        let photo = coder.decodeObject(forKey: PropertyKey.photo)as? UIImage
        
        self.init(name:name, date:date, photo:photo, datePaid:datePaid, summary:summary, price:price, dateReceipt:dateReceipt);
    }
var name: String
var date: String
var photo: UIImage?
var datePaid: String
var summary: String
var price: String
var dateReceipt: String
    
    
    init?(name:String, date:String, photo:UIImage?, datePaid:String, summary:String, price:String, dateReceipt:String){
        if(name.isEmpty || date.isEmpty || datePaid.isEmpty || summary.isEmpty || price.isEmpty || dateReceipt.isEmpty)
        {
        return nil;
        }
        self.name = name
        self.date = date
        self.photo = photo
        self.datePaid = datePaid
        self.summary = summary
        self.price = price
        self.dateReceipt = dateReceipt
    }
    
    struct PropertyKey{
        static let name = "name"
        static let date = "date"
        static let photo = "photo"
        static let datePaid = "datePaid"
        static let summary = "summary"
        static let price = "price"
        static let dateReceipt = "dateReceipt"
    }
    
    static let DocumentsDirectory =
        FileManager().urls(for:.documentDirectory, in:.userDomainMask).first!;
    static let ArchiveURL = DocumentsDirectory.appendingPathComponent("receiptEntries")
    
}
