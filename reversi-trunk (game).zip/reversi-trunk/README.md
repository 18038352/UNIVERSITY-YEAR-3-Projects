This is a simple parallel implementation of the classic reversi game.
# reversi
